/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ca.qc.bdeb.vue;

/**
 *
 * @author 1649904
 */
public enum Jeu {
    DRAG_DROP,
    SHOOTER,
    COUREUR,
    SPEED_RUN;
}
