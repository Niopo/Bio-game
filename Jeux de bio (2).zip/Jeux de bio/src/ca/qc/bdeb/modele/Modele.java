/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ca.qc.bdeb.modele;

import java.util.ArrayList;
import java.util.Observable;

/**
 *
 * @author 1649904
 */
public class Modele extends Observable {

    private final String locationFenetrePrincipale = "Ecrans\\Fenetre_principale.png";

    ArrayList<Utilisateur> listeUtilisateurs = new ArrayList<>();

    public Modele() {
        listeUtilisateurs.add(new Utilisateur("123", "123"));
        listeUtilisateurs.add(new Utilisateur("456", "456"));
        listeUtilisateurs.add(new Utilisateur("789", "789"));
    }

    public void majObserver() {
        setChanged();
        notifyObservers();
    }

    public String getLocationFenetrePrincipale() {
        return locationFenetrePrincipale;
    }

    //CETTE METHODE VA ÊTRE FIXED TANTOT 
    
    public void validerUtilisateur(String da, char[] motdepasse) {
        for (int i = 0; i < listeUtilisateurs.size(); i++) {
            if (this.listeUtilisateurs.get(i).getDa().equals(da)) {
                String motDePasse = "";
                
                
                
                if (this.listeUtilisateurs.get(i).getMotDePasse().equals()) {
                    //MOT DE PASSE ACCEPTÉ
                    System.out.println("Bienvenue " + listeUtilisateurs.get(i).getDa());
                } else {
                    //MOT DE PASSE INVALIDE
                }
            } else {
                //DA INVALIDE
            }
        }
    }

}
