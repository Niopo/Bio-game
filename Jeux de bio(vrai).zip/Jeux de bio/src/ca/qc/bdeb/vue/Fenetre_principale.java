/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ca.qc.bdeb.vue;

import ca.qc.bdeb.controleur.Controleur;
import ca.qc.bdeb.modele.Modele;
import java.util.Observable;
import java.util.Observer;

import javax.swing.*;

/**
 *
 * @author 1649904
 */
public class Fenetre_principale extends JFrame implements Observer {

    Controleur controleur;
    Modele modele;

    Monde_principale monde;

    Fenetre_jeu fenetre_jeu;

    public Fenetre_principale(Controleur controleur, Observable observable) {
        modele = (Modele) observable;
        modele.addObserver(this);
        this.controleur = controleur;

        creerInterface();

        this.pack();
        this.setVisible(true);
    }

    @Override
    public void update(Observable o, Object arg) {

    }

    private void creerInterface() {
        this.monde = new Monde_principale(modele, this);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setTitle("Jeux de bio!");
        this.add(monde);
    }

    public void ouvrirFenetreJeu(Jeu jeu) {
        fenetre_jeu = new Fenetre_jeu(jeu, this);

    }

    public void fermerFenetre() {
        this.fenetre_jeu.dispose();
        this.monde.finJeu();
    }

}
